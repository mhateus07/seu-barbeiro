# Seu Barbeiro — guia de marca (versão 2, outubro de 2026)

Seu Barbeiro é o sistema de gestão de barbearias e salões: agenda por profissional, clientes, comanda, Pix e caixa. A marca existe para o dono do salão confiar a ela o horário dos clientes e o dinheiro do caixa. Por isso ela é sóbria: parece um sistema bem feito, não uma campanha.

O nome se escreve sempre **Seu Barbeiro**, com as iniciais maiúsculas.

## Logo

A versão 2 trocou o símbolo ilustrado (relógio com tesoura) por um monograma. Não há ícone, desenho ou mascote.

- **Monograma**: as letras `SB` em IBM Plex Serif SemiBold, centradas num quadrado de cantos pouco arredondados (raio de 1/8 do lado).
- **Nome**: `Seu Barbeiro` em IBM Plex Serif SemiBold. A serifa é usada só no logo; o resto da marca é IBM Plex Sans.
- Uma tinta só: Azul Navalha com letras em Espuma no claro; Espuma com letras em Azul Navalha no escuro. Sem vermelho no logo.

Arquivos:

- `seu-barbeiro-horizontal.svg` e `-negativo`: versão principal (site, cabeçalho do painel, e-mail).
- `seu-barbeiro-vertical.svg`: espaços quadrados.
- `seu-barbeiro-simbolo.svg` e `-negativo`: só o monograma, para espaços pequenos.
- `seu-barbeiro-icone-app.svg`: ícone do app, favicon, foto de perfil.
- `seu-barbeiro-logotipo.svg`: só o nome.

Regras: use sempre os arquivos (as letras já estão convertidas em desenho). Área de proteção de meia altura do monograma em volta. Tamanho mínimo: monograma com 16px; logo horizontal com 120px de largura. Não gire, não aplique sombra, contorno, degradê, brilho ou dourado.

## Cor

| Cor | Token | Uso |
| --- | --- | --- |
| Azul Navalha `#15233F` | `marca-navalha` | Logo, botões principais, barra lateral do painel. |
| Espuma `#F5F4F0` | `marca-espuma` | Papel e logo negativo. |
| Azul Toalha `#C9DAEE` | `marca-toalha` | Fundos suaves de apoio. |
| Vermelho Poste `#D8462A` | `marca-poste` | Fora do logo. No painel, só a linha da hora atual na agenda. |

Na interface, use os tokens de papel (`surface`, `line`, `ink`, `brand`), não os de marca. Estados aparecem sempre com a palavra e um ícone; a cor sozinha nunca carrega a informação.

## Tipografia

- **IBM Plex Sans**: títulos (SemiBold 600) e todo o texto de interface e de leitura.
- **IBM Plex Mono**: horários e valores, alinhados em coluna como num livro-caixa.
- **IBM Plex Serif**: só no logo.

Títulos em frase normal ("Agenda de hoje"). Caixa alta só nos rótulos pequenos do painel. Dinheiro `R$ 45,00`; hora `09:30`; intervalo `09:30 – 10:15`.

## O que não usar

Nada que pareça gerado ou de modelo pronto: texto em degradê, brilho, vidro fosco, sombras grandes em cartão parado, emoji, ícone decorativo ao lado de cada frase, selo de "novo", molduras falsas de navegador, notificações de mentira, slogans em caixa alta acima dos títulos. Imagens do produto são gravações reais do sistema, com legenda dizendo o que mostram.

## Forma e espaço

Espaçamento em passos de 4. Cantos de 6 a 8px em botões e cartões. Cartões parados têm só a borda fina; sombra é para o que flutua (modal, item sendo arrastado). Separação de conteúdo por linhas finas antes de caixas.
